Tidicity on Android is a civic engagement app to make citiziens report common problems in their neighborhood!

Things to complete: 

1.  Get MapView to take the full view of the page
2.  Slider out, is not getting the view back to the original view. Left most tab view is out of view.
3.  Change the UI for uploading image and add imageURL and description.

